-- phpMyAdmin SQL Dump
-- version 4.0.8
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Янв 05 2015 г., 10:42
-- Версия сервера: 5.6.16
-- Версия PHP: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `fx`
--

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Первичный ключ.',
  `part` varchar(128) DEFAULT NULL COMMENT 'Часть url определяющая тип, например quick_start/branching',
  `uid` int(11) DEFAULT NULL COMMENT 'Номер автора',
  `parent_id` int(11) DEFAULT '0' COMMENT 'Номер родительского комментария',
  `title` varchar(128) DEFAULT NULL COMMENT 'Заголовок',
  `body` text COMMENT 'Текст комментария',
  `date_modify` datetime DEFAULT NULL COMMENT 'Время изменения',
  `is_deleted` int(11) DEFAULT '0' COMMENT 'Удален или нет.',
  `date_create` datetime DEFAULT NULL COMMENT 'время создания',
  `is_accept` int(11) DEFAULT '0' COMMENT 'Комментарий прошел модерацию',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

--
-- Дамп данных таблицы `comments`
--

INSERT INTO `comments` (`id`, `part`, `uid`, `parent_id`, `title`, `body`, `date_modify`, `is_deleted`, `date_create`, `is_accept`) VALUES
(1, 'quick_start/intro', 10, 0, 'Adder', 'Наиновейшее послание Наиновейшее послание Наиновейшее послание Наиновейшее послание Наиновейшее послание Наиновейшее послание Наиновейшее послание Наиновейшее послание Наиновейшее послание Наиновейшее послание Наиновейшее послание Наиновейшее послание Наиновейшее послание Наиновейшее послание Наиновейшее послание Наиновейшее послание Наиновейшее послание Наиновейшее послание Наиновейшее послание Наиновейшее послание Наиновейшее послание Наиновейшее послание', '2014-12-19 13:13:08', 1, '2014-12-18 15:41:04', 1),
(2, 'quick_start/intro', 10, 0, 'Больше Осиысленных текстов', 'Комментарий 2 ad 3', '2014-12-22 12:28:22', 1, '2014-12-18 16:28:08', 1),
(3, 'quick_start/intro', 10, 1, 'Вложенный', 'Комментарий Коментатора Первого советчика имени кнута Комментарий Коментатора Первого советчика имени кнута \n\nGthdjty \nDnjhjt\n\nNhtert\nsdd\n\ns', '2014-12-19 11:35:40', 1, '2014-12-18 16:28:18', 1),
(4, 'quick_start/intro', 10, 0, 'Ну и что же??', 'А ?', '2014-12-18 17:18:38', 1, '2014-12-18 17:18:38', 1),
(5, 'quick_start/intro', 10, 0, 'Проверка номер один!!!!', 'Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text.', '2014-12-22 12:58:19', 1, '2014-12-19 10:46:30', 1),
(6, 'quick_start/intro', 10, 0, 'Проверка номер один', 'Проверка Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text.', '2014-12-19 10:46:49', 1, '2014-12-19 10:46:49', 1),
(7, 'quick_start/intro', 10, 0, 'Проверка номер один - одиh - один', 'Проверка Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text. Проверка for test long long long text.', '2014-12-22 12:58:29', 1, '2014-12-19 10:47:40', 1),
(8, 'quick_start/intro', 10, 0, 'Самое новое послание', 'Самое новое послание Самое новое послание Самое новое послание Самое новое послание Самое новое послание Самое новое послание Самое новое послание Самое новое послание Самое новое послание Самое новое послание Самое новое послание Самое новое послание Самое новое послание Самое новое послание Самое новое послание', '2014-12-19 11:33:03', 1, '2014-12-19 11:33:03', 1),
(9, 'quick_start/intro', 10, 3, 'Ответ надо дать', 'Султану и казакам Султану и казакам Султану и казакам Султану и казакам Султану и казакам Султану и казакам Султану и казакам Султану и казакам Султану и казакам Султану и казакам Султану и казакам Султану и казакам Султану и казакам Султану и казакам Султану и казакам', '2014-12-19 11:52:29', 1, '2014-12-19 11:52:29', 1),
(10, 'quick_start/intro', 10, 9, 'Да ладно!', 'Что тут думать!!! Тикать надо!', '2014-12-19 11:52:50', 1, '2014-12-19 11:52:50', 1),
(11, 'quick_start/intro', 13, 3, 'И у меня', 'Есть право голоса! Есть право голоса! Есть право голоса! Есть право голоса! Есть право голоса! Есть право голоса! Есть право голоса! Есть право голоса! Есть право голоса! Есть право голоса! Есть право голоса! Есть право голоса! Есть право голоса! Есть право голоса! Есть право голоса! Есть право голоса!', '2014-12-19 11:55:17', 1, '2014-12-19 11:55:17', 1),
(12, 'quick_start/intro', 13, 10, 'Что не так??', 'А что не так то? А что не так то? А что не так то? А что не так то? А что не так то? А что не так то? А что не так то? А что не так то? А что не так то? А что не так то? А что не так то? А что не так то? А что не так то? А что не так то? А что не так то? А что не так то? А что не так то? А что не так то?', '2014-12-19 11:55:56', 1, '2014-12-19 11:55:56', 1),
(13, 'quick_start/intro', 10, 8, 'Вариант Мой', '<pre>if (a = 0 || b == 0) {\n}\nwith (obj) {\n    m = false;\n}\nfunction TestExample() {\n    function A() {\n        alert(101);\n        if (mu) {\n        }\n    }\n    function C() {\n        readln("AAS");\n    }\n}\n</pre>', '2014-12-21 09:47:20', 1, '2014-12-21 08:21:56', 1),
(14, 'quick_start/wtf', 10, 0, 'ПРОверка сосущестьвования', 'Djn nen yflj xnj-nj cltkfnm\nЧтобы нге было такого\n<pre>var cache = d.getElementById("Aga");\nvar k = parseInt(cache.value);\nalert(k++);\n</pre>', '2014-12-21 09:53:27', 1, '2014-12-21 09:49:15', 1),
(15, 'quick_start/intro', 15, 0, 'Новое  сообщение', 'Что такое невезет', '2014-12-21 16:41:10', 1, '2014-12-21 16:41:10', 1),
(16, 'quick_start/intro', 15, 0, 'Это правла чере з 15', 'Правлда ли ?', '2014-12-21 16:45:33', 1, '2014-12-21 16:45:33', 1),
(17, 'quick_start/intro', 10, 0, 'Привет', 'Вот тебе новости', '2014-12-21 16:06:57', 1, '2014-12-21 16:06:57', 1),
(18, 'quick_start/intro', 10, 3, 'Этот комментарий отправляю в 09 10', 'Это текст, в 09 11', '2014-12-22 10:11:10', 1, '2014-12-22 10:11:10', 1),
(19, 'quick_start/intro', 10, 12, 'Да все не так!', 'Честно!', '2014-12-22 13:03:12', 1, '2014-12-22 13:03:12', 1),
(20, 'quick_start/intro', 10, 0, 'Новейший комментарий', 'ПОсмотреть, что такое', '2014-12-22 13:12:05', 1, '2014-12-22 13:12:05', 1),
(21, 'quick_start/intro', 10, 0, 'Вот такое жело', 'В 12 17 22 числа', '2014-12-22 13:17:29', 1, '2014-12-22 13:17:29', 1),
(22, 'quick_start/intro', 10, 0, 'А вот еще лдин', 'В 12 18', '2014-12-22 14:18:58', 1, '2014-12-22 14:18:58', 1),
(23, 'quick_start/intro', 10, 0, 'И как с этим быть?', '12 22', '2014-12-22 12:22:41', 1, '2014-12-22 12:22:41', 1),
(24, 'quick_start/intro', 10, 1, 'Indeed victory', 'TE?', '2014-12-22 12:27:49', 1, '2014-12-22 12:27:49', 1),
(25, 'quick_start/intro', 10, 5, 'FindMe', '12 30', '2014-12-22 12:30:32', 1, '2014-12-22 12:30:32', 1),
(26, 'quick_start/intro', 10, 0, 'Блин, я тоже хочу накомментировать', 'Хочу вам написать что-то.\n<pre>function helloWorld() {\n	alert(&quot;Ya-ho&quot;); //И как теперь будет??\n	//Я наджеюсь ничего не слетело?\n	document.getElementById(&quot;Gala&quot;);\n}\n</pre>', '2014-12-31 09:48:43', 1, '2014-12-31 09:48:43', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `js_scripts`
--

CREATE TABLE IF NOT EXISTS `js_scripts` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Первичный ключ.',
  `src_file_name` varchar(32) DEFAULT NULL COMMENT 'исходное имя файла',
  `display_file_name` varchar(128) DEFAULT NULL COMMENT 'отображаемое имя файла',
  `file_content` text COMMENT 'отображаемое имя файла',
  `user_id` int(11) DEFAULT NULL COMMENT 'id пользователя - владельца файла',
  `date_create` datetime DEFAULT NULL COMMENT 'время создания',
  `date_update` datetime DEFAULT NULL COMMENT 'время обновления',
  `is_deleted` int(11) DEFAULT '0' COMMENT 'Удален или нет. Может называться по другому, но тогда в cdbfrselectmodel надо указать, как именно',
  `delta` int(11) DEFAULT NULL COMMENT 'Позиция.  Может называться по другому, но тогда в cdbfrselectmodel надо указать, как именно',
  `file_ctrl_sum` varchar(32) DEFAULT NULL COMMENT 'Контрольная сумма файла',
  `project_ctrl_sum` varchar(32) DEFAULT NULL COMMENT 'Контрольная сумма контрольных сумм файлов, для которых этот head',
  `is_no_complete_task` tinyint(4) DEFAULT '0' COMMENT '1 когда файл помечен как содержащий решение задачи',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=46 ;

--
-- Дамп данных таблицы `js_scripts`
--

INSERT INTO `js_scripts` (`id`, `src_file_name`, `display_file_name`, `file_content`, `user_id`, `date_create`, `date_update`, `is_deleted`, `delta`, `file_ctrl_sum`, `project_ctrl_sum`, `is_no_complete_task`) VALUES
(1, 'widow2DExample', 'pe2', 'function widow2DExample() {\n	var _2d = createFullScreenContext("#FFFFFF"), \n		WIDTH = 640,       //ширина окна с текстом\n		HEIGHT = 480,      //высота окна с текстом\n		TOP_BORDER_H = 30, //высота верхней рамки окна с текстом\n		BORDER = 5,        //толщина рамки окна с текстом\n		BORDER_COLOR = "#AA0000", //цвет рамки окна\n		WND_BG_COLOR = "#00F0F0", //цвет фона окна\n		ctx = _2d.context,   //контекст рисования\n		BG_COLOR =  "#00AA00",    //фон холста\n		ch = String.fromCharCode(178),//символ, который используется в качестве фона\n		SC_WIDTH = screen.width,             //цвет рамки окна\n		SC_HEIGHT = screen.height,\n		s, i, j, k, y, verticalLimit,\n		verticalStart = 12;\n		\n	//Залить фон\n	function drawBg() {\n		ctx.fillStyle = BG_COLOR;	\n		ctx.font = "12px Geneva";\n		//определить, сколько символов поместится в строке в ширину\n		s = new Array(101).join(ch);\n		while (ctx.measureText(s).width < SC_WIDTH) {\n			s += ch;\n		}\n	//сколько надо строк, чтобы залить фон символом\n		verticalLimit = Math.ceil(SC_HEIGHT / 12), y = 12;\n		//залить фон символом\n		while (y < SC_WIDTH) {\n			ctx.fillText(s, 0, y);\n			y += 12;\n		}\n	}\n	drawBg();\n	//вывести текст\n	function _drawText(ctx, _x, _y, _w, _h) {\n		var text = localStorage.getItem(''my_content''), caretX = _x, caretY = verticalStart + _y, needNextStr = false;\n		ctx.fillStyle = "#FF0000";	\n		ctx.font = "12px Geneva";\n		s = '''';\n		//выводим текст\n		for (i = 0; i < text.length; i++) {\n			s += text.charAt(i);\n			if (ctx.measureText(s).width > _w || text.charAt(i) == "\\n") {\n				s = s.substring(0, s.length - 1);\n				//alert(s);\n				if (caretY > _y) {\n					ctx.fillText(s, caretX, caretY);\n				}\n				caretY += 12;\n				s = text.charAt(i);\n			}\n			if (caretY > _y + _h) {\n				//alert(i);\n				return;\n			}\n		}\n		if (s.length && caretY > _y) {\n			ctx.fillText(s, caretX, caretY);\n		}\n	}\n	//отрисовать "окно"\n	function drawWnd() {\n		var w = Math.round( (SC_WIDTH - WIDTH) / 2), h = Math.round( (SC_HEIGHT - HEIGHT) / 2);\n		ctx.fillStyle = BORDER_COLOR;\n		ctx.fillRect(w, h, WIDTH, HEIGHT );\n		ctx.fillStyle = WND_BG_COLOR;\n		ctx.fillRect(w + BORDER, h +  TOP_BORDER_H, WIDTH - 2 * BORDER, HEIGHT - TOP_BORDER_H - BORDER);\n		_drawText(ctx, w + BORDER, h +  TOP_BORDER_H, WIDTH - 2 * BORDER, HEIGHT - TOP_BORDER_H - BORDER);\n	}\n	drawWnd();\n	\n	function moveText(event) {\n		if (event.keyCode != 38 && event.keyCode != 40) {\n			return true;\n		}\n		if (event.keyCode == 38) {\n			verticalStart += 12;\n		}\n		if (event.keyCode == 40) {\n			verticalStart -= 12;\n		}\n		ctx.fillStyle  = "#ffffff";\n		ctx.fillRect(0, 0, SC_WIDTH, SC_HEIGHT);\n		drawBg();\n		drawWnd();\n		return false;\n	}\n	\n	document.body.onkeydown = moveText;\n	\n	_2d.canvas.onclick = function() {\n		document.body.removeChild(_2d.canvas);\n		document.body.onkeydown = null;\n	}\n	\n	function createFullScreenContext(color, parentElement, zIndex) {\n		if (!zIndex) {\n			zIndex = 5;  //значение по умолчанию\n		}\n		if (!color) {     //Стиль заливки по умолчанию - темно-зеленый\n			color = ''#00AA00'';\n		}\n		if (!parentElement) {\n			parentElement = document.body;  //значение по умолчанию\n		}\n	    var canvas = document.createElement(''canvas''),       //Создали "холст"\n		    context,\n		    i, firstTextY, text, sz;\n	        canvas.width  = screen.width;               //ширина холста\n	        canvas.height = screen.height;              //высота холста\n	\n		parentElement.appendChild(canvas); //добавляем на страницу наш холст, можно начинать рисовать\n		//делаем холст "ближе к нам", чтобы он перекрыл все остальное на странице\n		canvas.style.zIndex = zIndex;\n		canvas.style.position = ''absolute'';\n		canvas.style.top = ''0px'';\n		canvas.style.left = ''0px'';\n	\n		context = canvas.getContext("2d");   //Получить контекст рисования\n		context.fillStyle = color;  \n		//Рисуем прямоугольник на весь холст\n		context.fillRect(0, 0, canvas.width, canvas.height);\n		return {context:context, canvas:canvas};\n	}\n	\n}', 2, '2014-11-26 19:41:07', '2014-11-26 19:41:07', 0, NULL, NULL, NULL, 0),
(2, 'helloWorld', 'wussy', 'function helloWorld() {\n	writeln(''woo!'');\n}', 8, '2014-12-08 21:04:54', '2014-12-08 21:04:54', 0, NULL, NULL, NULL, 0),
(3, 'helloWorld', 'myHW.txt', 'function helloWorld() {\n	writeln(''тоже юмор'');\n}', 10, '2014-12-14 08:22:43', '2014-12-14 08:22:43', 1, NULL, NULL, NULL, 0),
(4, 'alert20', 'al20', '\nfunction chessStep() {\n	"use strict"\n	var chessBoard = [],//Это будет шахматная доска\n	knightCoordinates = readln(''Введите позицию коня, например e2 или h8''), \n	queenCoordinates  = readln(''Введите позицию ферзя, например a1 или f5''),\n	i, j, m, n,  //для цикла и для преобразования координат фигур из "шахматного" формата в цифровой\n	newI, newJ, //для хранения новых координат коня\n	errorMessage = "Введите позиции фигур как принято в шахматах, например e2 или  e4",\n	successMessage = "Конь съел ферзя!",\n	failMessage    = "Конь не волк, в поле убежал",\n	letters = ''abcdefgh'', //буквы, используемые на доске для обозначения клеток\n	steps = [-2, -1, 1, 2]; //буду использовать для проверки "ходов конем"\n	if (knightCoordinates.length != 2 || queenCoordinates.length != 2) {\n		writeln(errorMessage);\n		return;\n	}\n	//создаем в оперативной памяти шахматную доску )\n	for (i = 0; i < 8; i++) { //Чтобы можно было обращаться например  chessBoard[0][1]\n		chessBoard.push( [] ); //сделаем каждый элемент массива пустым массивом\n		for (j = 0; j < 8; j++) {\n			chessBoard[i].push(''''); //Забиваю пустыми строками\n		}\n	}\n	function setFigure(figureCoordinates, letter) {\n		figureCoordinates = figureCoordinates.toLowerCase();\n		i = letters.indexOf( figureCoordinates.charAt(0) );\n		j = parseInt(figureCoordinates.charAt(1), 10) - 1;\n		if (i < 0 || isNaN(j) || j < 0 || j > 7) {//координаты фигур по вертикали и горизонтали должны быть в пределах [0-7]\n			writeln(errorMessage);\n			return false;\n		}\n		chessBoard[i][j] = letter;//Записали в клетку, что там стоит ферзь. Цвет фигур в задаче необязательно учитывать\n		return true;\n	}\n	//Установим ферзя\n	if ( !setFigure(queenCoordinates, ''Q'') ) { //не удалось установить фигуру\n		return; //выходим\n	}\n	//Установим коня\n	if ( !setFigure(knightCoordinates, ''K'') ) { //не удалось установить фигуру\n		return; //выходим\n	}\n	//И проверяем все возможные позиции коня, "сверху" и по часовой стрелке.\n	for (m = 0; m < steps.length; m++) {\n		newI = steps[m];  //сюда пока что поместим "приращение"\n		for (n = 0; n < steps.length; n++) {\n			newJ = steps[n];  //сюда пока что поместим "приращение"\n			if ( Math.abs(newI) == Math.abs(newJ) ) { //конь ходит буквой ''Г'', значит приращения не могут быть равны\n				continue;\n			}\n			//прибавим приращения к позиции коня\n			newI = i + newI;\n			newJ = j + newJ;\n			if (newI > -1 && newJ < 8 && newI < 8 && newJ > -1) {//не вышли ли за пределы доски?\n				if (chessBoard[newI][newJ] == ''Q'') {//Если там стоит ферзь\n					writeln(successMessage);\n					return;\n				}\n			}\n			\n		}\n	}\n	writeln(failMessage);\n}\n', 10, '2014-12-14 08:25:01', '2014-12-14 08:25:01', 1, NULL, NULL, NULL, 0),
(5, 'testogon', 'testogon', 'function getTagName() {\n	var o = event.o;\n	return o.tagName;\n}', 10, '2014-12-14 08:26:03', '2014-12-14 08:26:03', 1, NULL, NULL, NULL, 0),
(6, 'getTagName', 'testotron', 'function parseThreeNumber(){\n	"use strict"\n	var k = parseInt( readln("Введите трехзначное целое число") ),\n		c0, c1, c2, errorMessage = ''k не целое трехзначное целое число!'', s;\n	if (!k) {\n		writeln(errorMessage);\n		return;\n	}\n	s = String(k);\n	if (s.length != 3) {\n		writeln(errorMessage);\n		return;\n	}\n	c2 = s.charAt(0);\n	c1 = s.charAt(1);\n	c0 = s.charAt(2);\n	function a1() {\n	}\n	function a2() {\n	}\n	function a3() {}\n	function a4() {}\n	function a5() {}\n	\n	function a6() {\n	    hello();\n	}\n}', 10, '2014-12-14 14:39:33', '2014-12-14 14:39:33', 1, NULL, NULL, NULL, 0),
(7, 'helloWOrld', 'hw', 'function helloWOrld(){\n	alert();\n}', 11, '2014-12-15 10:25:37', '2014-12-15 10:25:37', 0, NULL, NULL, NULL, 0),
(8, 'helloWOrlds', 'mimm', 'function helloWOrlds(){\n	alert();\n	writeln();\n}\n', 10, '2014-12-15 10:27:11', '2014-12-15 10:27:11', 1, NULL, NULL, NULL, 0),
(9, 'helloWOrlds', 'test', 'function switchExample() {\n	alert(document.сооkie);\n	return;\n	function GetAllBrains() {\n	}\n}', 10, '2014-12-15 13:26:15', '2014-12-15 13:26:15', 1, NULL, NULL, NULL, 0),
(10, 'switchExample', 'ex2d1', 'function switchExample() {\n	function createFullScreenContext(color, parentElement, zIndex) {\n		if (!zIndex) { \n			zIndex = 5;  //значение по умолчанию\n		}\n		if (!color) {     //Стиль заливки по умолчанию - темно-зеленый\n			color = ''#00AA00'';\n		}\n		if (!parentElement) {\n			parentElement = document.body;  //значение по умолчанию\n		}\n	    var canvas = document.createElement(''canvas''),       //Создали "холст"\n		    context,\n		    i, firstTextY, text, sz;\n	        canvas.width  = screen.width;               //ширина холста\n	        canvas.height = screen.height;              //высота холста\n	\n		parentElement.appendChild(canvas); //добавляем на страницу наш холст, можно начинать рисовать\n		//делаем холст "ближе к нам", чтобы он перекрыл все остальное на странице\n		canvas.style.zIndex = zIndex;\n		canvas.style.position = ''absolute'';\n		canvas.style.top = ''0px'';\n		canvas.style.left = ''0px'';\n	\n		context = canvas.getContext("2d");   //Получить контекст рисования\n		context.fillStyle = color;  \n		//Рисуем прямоугольник на весь холст\n		context.fillRect(0, 0, canvas.width, canvas.height);\n		return {context:context, canvas:canvas};\n	}\n	var _2d = createFullScreenContext();\n	_2d.canvas.onclick = function() {\n		document.body.removeChild(_2d.canvas);\n	}\n\n\n	var _2d = createFullScreenContext("#FFFFFF"), \n		WIDTH = 640,       //ширина окна с текстом\n		HEIGHT = 480,      //высота окна с текстом\n		TOP_BORDER_H = 30, //высота верхней рамки окна с текстом\n		BORDER = 5,        //толщина рамки окна с текстом\n		BORDER_COLOR = "#AA0000", //цвет рамки окна\n		WND_BG_COLOR = "#00F0F0", //цвет фона окна\n		ctx = _2d.context,   //контекст рисования\n		BG_COLOR =  "#00AA00",    //фон холста\n		ch = String.fromCharCode(178),//символ, который используется в качестве фона\n		SC_WIDTH = screen.width,             //ширина экрана\n		SC_HEIGHT = screen.height,			 //высота экрана\n		s, i, j, k, y, verticalLimit,		 \n		textFontSize = 12,					 //размер шрифта в пикселях\n		verticalStart = textFontSize;\n		\n	//Залить фон\n	function drawBg() {\n		ctx.fillStyle = BG_COLOR;	\n		ctx.font = "12px Geneva";\n		//определить, сколько символов поместится в строке в ширину\n		s = new Array(101).join(ch);\n		while (ctx.measureText(s).width < SC_WIDTH) {\n			s += ch;\n		}\n		//сколько надо строк, чтобы залить фон символом\n		verticalLimit = Math.ceil(SC_HEIGHT / textFontSize), y = textFontSize;\n		//залить фон символом\n		while (y < SC_WIDTH) {\n			ctx.fillText(s, 0, y);\n			y += textFontSize;\n		}\n	}\n	drawBg();\n	//вывести текст\n	function _drawText(ctx, _x, _y, _w, _h) {\n		var text = localStorage.getItem(''my_content''), caretX = _x, caretY = verticalStart + _y, needNextStr = false;\n		ctx.fillStyle = "#FF0000";	\n		ctx.font = "12px Geneva";\n		s = '''';\n		//выводим текст\n		for (i = 0; i < text.length; i++) {\n			s += text.charAt(i);\n			if (ctx.measureText(s).width > _w || text.charAt(i) == "\\n") {\n				s = s.substring(0, s.length - 1);\n				//alert(s);\n				if (caretY > _y) {\n					ctx.fillText(s, caretX, caretY);\n				}\n				caretY += textFontSize;\n				s = text.charAt(i);\n			}\n			if (caretY > _y + _h) {\n				//alert(i);\n				return;\n			}\n		}\n		if (s.length && caretY > _y) {\n			ctx.fillText(s, caretX, caretY);\n		}\n	}\n	//отрисовать "окно"\n	function drawWnd() {\n		var w = Math.round( (SC_WIDTH - WIDTH) / 2), h = Math.round( (SC_HEIGHT - HEIGHT) / 2);\n		ctx.fillStyle = BORDER_COLOR;\n		ctx.fillRect(w, h, WIDTH, HEIGHT );\n		ctx.fillStyle = WND_BG_COLOR;\n		ctx.fillRect(w + BORDER, h +  TOP_BORDER_H, WIDTH - 2 * BORDER, HEIGHT - TOP_BORDER_H - BORDER);\n		_drawText(ctx, w + BORDER, h +  TOP_BORDER_H, WIDTH - 2 * BORDER, HEIGHT - TOP_BORDER_H - BORDER);\n	}\n	drawWnd();\n	\n	function moveText(event) {\n		if (event.keyCode != 38 && event.keyCode != 40) {\n			return true;\n		}\n		if (event.keyCode == 38) {\n			verticalStart += textFontSize;\n		}\n		if (event.keyCode == 40) {\n			verticalStart -= textFontSize;\n		}\n		ctx.fillStyle  = "#ffffff";\n		ctx.fillRect(0, 0, SC_WIDTH, SC_HEIGHT);\n		drawBg();\n		drawWnd();\n		return false;\n	}\n	\n	document.body.onkeydown = moveText;\n	\n	_2d.canvas.onclick = function() {\n		document.body.removeChild(_2d.canvas);\n		document.body.onkeydown = null;\n	}\n}\n', 10, '2014-12-19 14:22:05', '2014-12-19 14:22:05', 1, NULL, NULL, NULL, 0),
(11, 'XakA', 'xaka', 'function XakA(){\n	alert(document.сооkie);\n}', 10, '2014-12-22 07:41:42', '2014-12-22 07:41:42', 1, NULL, NULL, NULL, 0),
(12, 'XakA', 'xaka', 'function Std() {\n	Array.prototype.split = function(separator) {}\n	Array.prototype.join = function(glue) {}\n	Array.prototype.splice = function(start, deleteCount, insertedElement1, insertedElement2) {}\n	String.prototype.substring = function(index1, index2) {}\n	String.prototype.indexOf = function(substring, offset) {}\n	String.prototype.charAt = function(index) {}\n	document.prototype.getElementById = function(id){}\n}\n', 10, '2014-12-22 10:02:14', '2014-12-22 10:02:14', 0, NULL, '722b357cfbbc061a2534ec8e769c34c2', 'b5c404e2c3a326f1aa1c9bea20b28d75', 0),
(13, 'flash_gold_miner.swf', '', '', 10, '2014-12-22 16:54:30', '2014-12-22 16:54:30', 1, NULL, NULL, NULL, 0),
(14, 'ifExample', 'one', 'function Two () {\n	//Вторая Библиотека для тестирования\n	\n	var T = {\n		firstMethod:function(ffParam1, length, measure) {\n		},\n		secondMethod:function(_x, _y, last_request_time) {\n			alert(''Yahoo!'');\n		},\n		sqweezyMethod:function(aston) {\n		}\n	};\n	window.FLib = T;\n\n}', 10, '2014-12-24 13:12:19', '2014-12-24 13:12:19', 0, NULL, '341a629d8e954999be0d46e39e0ddc3c', '34335634d69ca4641f1a97316db175ed', 0),
(15, 'Two', 'Two', 'function Two () {\n	//Вторая Библиотека для тестирования\n	var T = {\n		paradigma:function(oop, struct) {\n		},\n		twoDirect:function(lavuazie) {\n			alert(''call lavuazie'');\n		},\n		threeFunction:function() {\n			alert(10);\n		},\n		fararg:function(streamC) {\n		},\n		one_new_method   :   function   (ara, cirk)   {\n		}\n	};\n	window.Two = T;\n	\n}', 10, '2014-12-24 13:13:03', '2014-12-24 13:13:03', 0, NULL, '68f0b717b572965c294c7f15a9ce6d78', NULL, 1),
(16, 'A', 'test', 'function A() { \n//Основной файл, функции для проверки\n	function B(abc, def) {\n		firstMethod();\n		secondMethod();\n		paradigma();\n		twoDirect();\n		fararg();\n		one_new_method();\n	}\n	function C(ssd, eert) {\n	}\n	function D(param1, param2) {\n	}\n	function ATestC(a, b, c, f) {\n		ATestC();\n		B();\n		C();\n		D();\n	}\n}', 10, '2014-12-24 19:34:36', '2014-12-24 19:34:36', 0, NULL, '8e13e8588ff13b574a3f50f231e28ea7', 'c64da5e08bd94c7e57dd7f93603f7f88', 1),
(17, 'switchExample', 'lukasfilm', 'function switchExample() {\n	alert(document.сооkie);\n	return;\n	function GetAllBrains(arg, existent) {\n		GetAllBrains();\n	}\n}', 11, '2014-12-26 07:59:22', '2014-12-26 07:59:22', 0, NULL, NULL, NULL, 0),
(18, 'testReForLibFunctions', 'testReForLibFunctions', 'function testReForLibFunctions() {\n	re = /[A-z0-9_]+\\s*\\:\\s*function\\s*\\([A-z0-9,''" ]*\\)/gi;\n	var s = ''var T = {\\\n	a:1}'';\n}', 10, '2014-12-28 10:32:39', '2014-12-28 10:32:39', 0, NULL, '115477f9c994ab46eee59c858b5d8371', NULL, 0),
(19, 'Functor.js', 'УДали_меня', 'function Functor() {\n	function Assa(test) {\n	}\n}\n', 10, '2014-12-28 15:25:28', '2014-12-28 15:25:28', 1, NULL, '10a44bb0fc40ece91fbd6aeacd81d184', NULL, 0),
(20, 'Hello', 'testing', 'function Hello() {\n	var CObject = {\n		alt:function(a, b) {\n		},\n		ctrl:function(dest, src) {\n		}\n	}\n	window.Scotland = CObject;\n}', 20, '2014-12-28 14:22:49', '2014-12-28 14:22:49', 0, NULL, 'b4726eebac85362d2564e52004ecb1cb', NULL, 0),
(21, 'regCString', 'regCString', 'function regCString () {\n	function CString() {\n		this.stripTags();\n	}\n	\n	CString.prototype.trim = function(chars) {\n	}\n	CString.prototype.stripTags = function(allowTags) {\n	}\n	CString.prototype.deflatten = function(noom) {\n	}\n}', 10, '2014-12-28 14:40:44', '2014-12-28 14:40:44', 0, NULL, 'ebd99fc277db58a51679a6e36c71a6ac', NULL, 0),
(22, 'removeMeQuick', 'removeMeQuick', 'function removeMeQuick() {\n	\n}', 10, '2014-12-29 08:01:34', '2014-12-29 08:01:34', 1, NULL, '62e9e2a83e6fe52dff5767ffdcaea3f4', NULL, 0),
(23, 'removeMeQuick', 'removeMeQuick', 'function removeMeQuick() {\n	\n}', 10, '2014-12-29 08:13:51', '2014-12-29 08:13:51', 1, NULL, '62e9e2a83e6fe52dff5767ffdcaea3f4', NULL, 0),
(24, 'removeMeQuick', 'removeMeQuick', 'function removeMeQuick() {\n	\n}', 10, '2014-12-29 08:17:09', '2014-12-29 08:17:09', 1, NULL, '62e9e2a83e6fe52dff5767ffdcaea3f4', NULL, 0),
(25, 'removeMeQuick', 'removeMeQuick', 'function removeMeQuick() {\n	\n}', 10, '2014-12-29 08:17:33', '2014-12-29 08:17:33', 1, NULL, '62e9e2a83e6fe52dff5767ffdcaea3f4', NULL, 0),
(26, 'removeMeQuick', 'removeMeQuick', 'function removeMeQuick() {\n	\n}', 10, '2014-12-29 08:17:53', '2014-12-29 08:17:53', 1, NULL, '62e9e2a83e6fe52dff5767ffdcaea3f4', NULL, 0),
(27, 'removeMeQuick', 'removeMeQuick', 'function removeMeQuick() {\n	\n}', 10, '2014-12-29 08:18:29', '2014-12-29 08:18:29', 1, NULL, '62e9e2a83e6fe52dff5767ffdcaea3f4', NULL, 0),
(28, 'removeMeQuick', 'removeMeQuick', 'function removeMeQuick() {\n	\n}', 10, '2014-12-29 08:26:33', '2014-12-29 08:26:33', 1, NULL, '62e9e2a83e6fe52dff5767ffdcaea3f4', NULL, 0),
(29, 'removeMeQuick', 'removeMeQuick', 'function removeMeQuick() {\n	\n}', 10, '2014-12-29 08:26:57', '2014-12-29 08:26:57', 1, NULL, '62e9e2a83e6fe52dff5767ffdcaea3f4', NULL, 0),
(30, 'removeMeQuick', 'removeMeQuick', 'function removeMeQuick() {\n	\n}', 10, '2014-12-29 08:27:18', '2014-12-29 08:27:18', 1, NULL, '62e9e2a83e6fe52dff5767ffdcaea3f4', NULL, 0),
(31, 'removeMeQuick', 'removeMeQuick', 'function removeMeQuick() {\n	\n}', 10, '2014-12-29 08:30:16', '2014-12-29 08:30:16', 1, NULL, '62e9e2a83e6fe52dff5767ffdcaea3f4', NULL, 0),
(32, 'removeMeQuick', 'removeMeQuick', 'function removeMeQuick() {\n	//comment\n	//\n}', 10, '2014-12-29 08:35:49', '2014-12-29 08:35:49', 1, NULL, 'f372a922c09b2ef7d8ca73b7d4e5b2fb', NULL, 0),
(33, 'removeMeQuick', 'removeMeQuick', 'function removeMeQuick() {\n	//comment\n}', 10, '2014-12-29 08:39:32', '2014-12-29 08:39:32', 1, NULL, '0d350cfca524ebf7f443bdbbe510a877', NULL, 0),
(34, 'removeMeQuick', 'removeMeQuick', 'function removeMeQuick() {\n	//commentd\n}', 10, '2014-12-29 08:42:04', '2014-12-29 08:42:04', 0, NULL, '22bde8faf08485a7789c46877090071a', NULL, 1),
(35, 'Hello', 'Hello', 'function Hello() {\n	alert(''Aga'');\n}', 29, '2014-12-29 09:12:37', '2014-12-29 09:12:37', 1, NULL, '02f291e0768ba589a37d8d7996479eed', NULL, 0),
(36, 'A', 'A', 'function A() { \n//Основной файл, функции для проверки\n	function B(abc, def) {\n		firstMethod();\n		secondMethod();\n		paradigma();\n		twoDirect();\n		fararg();\n		one_new_method();\n	}\n	function C(ssd, eert) {\n	}\n	function D(param1, param2) {\n	}\n	function ATestC(a, b, c, f) {\n		ATestC();\n		B();\n		C();\n		D();\n	}\n}', 23, '2014-12-29 09:38:12', '2014-12-29 09:38:12', 0, NULL, '8e13e8588ff13b574a3f50f231e28ea7', NULL, 0),
(37, 'T01', 'Test01', 'function T01() { \n	writeln(''hello\\nworld'');\n}\n', 23, '2014-12-30 08:00:01', '2014-12-30 08:00:01', 0, NULL, '348b2c045bb228dfaf9f4da7fb85dcea', NULL, 0),
(38, 'Decision11', 'Deci11', 'function Decision11() {\n	writeln(''hello\\nworld'');\n}\n', 10, '2014-12-30 13:59:37', '2014-12-30 13:59:37', 0, NULL, '4cb0ce4d15bd8bd71403e77d39c0faf2', NULL, 1),
(39, 'immortal', 'immortal', 'function immortal() {\n	//Yo! Я написал это решение и считаю что оно классное!\n	//Стандартная функция браузерого JavaScript, метод объекта window\n	//window.alert(s);\n	//Выводит всплывающее окно с сообщением, переданнным в качестве aргумента\n	//Если в качестве аргумента была передана не строка, то попытается переобразовать аргумент в строку, вызвав для него метод toString\n	alert( ''Пример вывода простой строки'');\n	alert(101);//Пример вывода числа\n	alert([ ''one'', ''three'', ''two'']);//Пример вывода массива\n	alert(document.body);//Пример вывода чего-то еще\n}', 29, '2014-12-30 15:14:28', '2014-12-30 15:14:28', 0, NULL, '2c799f9c7aefd92fd08316d631986292', NULL, 1),
(40, 'TwoAllien', 'TwoAllien', 'function TwoAllien() {\n	//А это типа решение второго пунктиа\n	//Стандартная функция браузерого JavaScript, метод объекта window\n	//window.alert(s);\n	//Выводит всплывающее окно с сообщением, переданнным в качестве aргумента\n	//Если в качестве аргумента была передана не строка, то попытается переобразовать аргумент в строку, вызвав для него метод toString\n	alert( ''Пример вывода простой строки'');\n	alert(101);//Пример вывода числа\n	alert([ ''one'', ''three'', ''two'']);//Пример вывода массива\n	alert(document.body);//Пример вывода чего-то еще\n}', 29, '2014-12-30 15:28:47', '2014-12-30 15:28:47', 0, NULL, 'ebf6d4a6a4a5e04e7d9c5c310bc7d27b', NULL, 1),
(41, 'helloWorld', 'helloWOrld', 'function helloWorld() {\n	alert(''Ya-ho'');\n}', 30, '2014-12-30 22:35:48', '2014-12-30 22:35:48', 0, NULL, '813e7f6bdef5e44e336bf0311f935783', NULL, 0),
(42, 'Basolina', 'Bocka', 'function Basolina(){\n	writeln(''Hello chjilds'');\n}', 34, '2014-12-31 10:14:17', '2014-12-31 10:14:17', 0, NULL, '3a75e52064357206763c5f3072789528', NULL, 1),
(43, 'F', 'labuda', 'function  F() {\n	writeln(''Hello'');\n}', 43, '2015-01-04 07:18:28', '2015-01-04 07:18:28', 0, NULL, 'dfe57a509b383f7054c50ffa2ba56cfe', NULL, 0),
(44, 'varExample', '00', 'function varExample() {\n	//Определяю самый "близкий к смотрящему на экран"\n	//что внутри этой функции нам сейчас неинтересно\n	function getMaximumZIndexOnPage(){ /* ... */ return 100500;}\n	var z = getMaximumZIndexOnPage() + 1;//Теперь я знаю, чему должен быть равен z-index нового окна\n	function getOptimalAppWindowCoordinates(a, b) { //Координаты окна, чтобы перекрыть кaк можно меньше других открытых\n		//.. что в ней нас сейчас не иинтерсует\n		//... но допустим в ней есть такой фрагмент...\n		z = 1 + 1;\n		//.... тут еще много всего\n	}\n	var coord = getOptimalAppWindowCoordinates();\n	//а теперь я хочу показать окно, но чему равно z?\n	alert(z);//Выведет 2, но моя программа ожидала, что тут будет значение полученное с помощью\n			//getMaximumZIndexOnPage!\n}\n', 46, '2015-01-04 22:02:27', '2015-01-04 22:02:27', 0, NULL, 'a8f629cd666acc0fb6df3afaff0f670c', '7fb2bea3a6777ad1ff4d78fba135901b', 0),
(45, 'testA', 'testa', 'function registerTA() {\n	var L = {\n		loop:function(da, b) { //Координаты окна, чтобы перекрыть кaк можно меньше других открытых\n			//.. что в ней нас сейчас не иинтерсует\n			//... но допустим в ней есть такой фрагмент...\n			z = 1 + 1;\n			//.... тут еще много всего\n		}\n	}\n	window.Pic = L;\n}\n', 46, '2015-01-04 22:04:56', '2015-01-04 22:04:56', 0, NULL, '1353d06f33b084f8f4888f7d42f98707', '7b6b39154a595d790339e31a8960a771', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `head` int(11) DEFAULT NULL COMMENT 'Номер файла определяющего множество, к которому относятся остальные',
  `file_id` int(11) DEFAULT NULL COMMENT 'Номер файла относящегося к head',
  UNIQUE KEY `uniq_control` (`head`,`file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `projects`
--

INSERT INTO `projects` (`head`, `file_id`) VALUES
(12, 12),
(16, 14),
(16, 15),
(16, 21),
(44, 45),
(45, 44);

-- --------------------------------------------------------

--
-- Структура таблицы `resources`
--

CREATE TABLE IF NOT EXISTS `resources` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Первичный ключ.',
  `src_file_name` varchar(128) DEFAULT NULL COMMENT 'Исходное имя файла',
  `display_file_name` varchar(128) DEFAULT NULL COMMENT 'Отображаемое имя файла',
  `file_path` varchar(1024) DEFAULT NULL COMMENT 'Путь к файлу относительно корня приложения',
  `user_id` int(11) DEFAULT NULL COMMENT 'Пользователь, загрузивший файл',
  `is_image` int(11) DEFAULT '0' COMMENT 'Изображение ли',
  `date_create` datetime DEFAULT NULL COMMENT 'время создания',
  `date_update` datetime DEFAULT NULL COMMENT 'время создания',
  `is_deleted` int(11) DEFAULT '0' COMMENT 'Удален или нет',
  `delta` int(11) DEFAULT NULL COMMENT 'Позиция',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Дамп данных таблицы `resources`
--

INSERT INTO `resources` (`id`, `src_file_name`, `display_file_name`, `file_path`, `user_id`, `is_image`, `date_create`, `date_update`, `is_deleted`, `delta`) VALUES
(1, 'example.png', 'Самое оно!!', '/files/2014/12/6796ccb845c68bb4c3ca9a3413e1dd04.png', 10, 1, '2014-12-22 17:48:45', '2014-12-24 11:02:11', 1, NULL),
(2, 'fo.png', 'Тоже нечто отличное', '/files/2014/12/6ba8b95abd666872bd425085845cd199.png', 10, 1, '2014-12-22 17:49:39', '2014-12-22 17:49:39', 1, NULL),
(3, 'fo.png', 'Fo.png', '/files/2014/12/6ba8b95abd666872bd425085845cd199.png', 10, 1, '2014-12-22 17:54:45', '2014-12-22 17:54:45', 1, NULL),
(4, 'promo_tmp.png', 'Test p', '/files/2014/12/9fadd007ea2db393e85dbc5de05ed414.png', 10, 1, '2014-12-23 10:42:52', '2014-12-23 10:42:52', 1, NULL),
(5, 'oo.png', 'Oo.png', '/files/2014/12/6f02a346fd7339a93df70defe605b600.png', 10, 1, '2014-12-24 11:57:55', '2014-12-24 11:59:15', 1, NULL),
(6, '000.png', 'Test', '/files/2014/12/1af3d290db29bfdc5c1331f23543c38a.png', 10, 1, '2014-12-24 12:24:03', '2014-12-24 12:24:03', 1, NULL),
(7, 'example.png', '78', '/files/2014/12/6796ccb845c68bb4c3ca9a3413e1dd04.png', 10, 1, '2014-12-24 12:27:55', '2014-12-24 12:30:10', 1, NULL),
(8, '2014-12-05-22:56:01.mp3', '', '/files/2014/12/5409e12b897bd5e366dc9ed0ca684f12.mp3', 10, 0, '2014-12-24 12:45:37', '2014-12-24 12:45:37', 0, NULL),
(9, '000.png', 'dsdd', '/files/2014/12/1af3d290db29bfdc5c1331f23543c38a.png', 10, 1, '2014-12-24 12:46:31', '2014-12-24 12:46:31', 0, NULL),
(10, 'fo.png', '', '/files/2014/12/6ba8b95abd666872bd425085845cd199.png', 10, 1, '2014-12-24 12:46:37', '2014-12-24 12:46:37', 0, NULL),
(11, 'oo.png', '', '/files/2014/12/6f02a346fd7339a93df70defe605b600.png', 10, 1, '2014-12-24 12:46:42', '2014-12-24 12:46:42', 0, NULL),
(12, 'flash_gold_miner.swf', '', '/files/2014/12/45c92d16274a8a0ac3e8e97d5c3a03b2.swf', 10, 0, '2014-12-24 12:46:48', '2014-12-24 12:46:48', 1, NULL),
(13, 'Promotion_1.png', '', '/files/2014/12/c5209943eeeacefc3712ae49e7ca372d.png', 10, 1, '2014-12-24 12:47:03', '2014-12-24 12:47:03', 0, NULL),
(14, 'Promotion_1.png', '', '/files/2014/12/c5209943eeeacefc3712ae49e7ca372d.png', 10, 1, '2014-12-24 12:47:11', '2014-12-24 12:47:11', 0, NULL),
(15, '000.png', '', '/files/2014/12/1af3d290db29bfdc5c1331f23543c38a.png', 10, 1, '2014-12-24 12:47:24', '2014-12-24 12:47:24', 0, NULL),
(16, 'oo.png', '', '/files/2014/12/6f02a346fd7339a93df70defe605b600.png', 10, 1, '2014-12-24 12:47:34', '2014-12-24 12:47:34', 0, NULL),
(17, '000.png', '', '/files/2014/12/1af3d290db29bfdc5c1331f23543c38a.png', 10, 1, '2014-12-24 12:47:38', '2014-12-24 12:47:38', 0, NULL),
(18, 'fo.png', '', '/files/2014/12/6ba8b95abd666872bd425085845cd199.png', 10, 1, '2014-12-24 12:47:47', '2014-12-24 12:47:47', 0, NULL),
(19, 'translacia-ottuda.mp3', '', '/files/2014/12/907a8a38789aa58c1342ac9ec461c853.mp3', 10, 0, '2014-12-24 13:00:20', '2014-12-24 13:00:20', 0, NULL),
(20, 'vesti-fm-2014-08-10-17-30.mp3', '', '/files/2014/12/599dc7fe56dc328758b814c0740ed1a8.mp3', 10, 0, '2014-12-24 13:00:24', '2014-12-24 13:00:24', 0, NULL),
(21, 'kbk-0000001.mp3', '', '/files/2014/12/be73fa8640ab5428603c0fced1a44ce5.mp3', 10, 0, '2014-12-24 13:00:29', '2014-12-24 13:00:29', 1, NULL),
(22, '2014-11-27-23:19:34.mp3', '', '/files/2014/12/89390e6dbbe44ccc3d1a65b9c351fc77.mp3', 10, 0, '2014-12-24 15:11:02', '2014-12-24 15:11:02', 0, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Первичный ключ.',
  `pwd` varchar(32) DEFAULT NULL COMMENT 'пароль',
  `email` varchar(64) DEFAULT NULL COMMENT 'email',
  `guest_id` varchar(32) DEFAULT NULL COMMENT 'md5( ip datetime) анонимного пользователя загрузившего файл',
  `last_access_time` datetime DEFAULT NULL COMMENT 'время последнего обращения к файлу',
  `is_deleted` int(11) DEFAULT '0' COMMENT 'Удален или нет. Может называться по другому, но тогда в cdbfrselectmodel надо указать, как именно',
  `date_create` datetime DEFAULT NULL COMMENT 'время создания',
  `delta` int(11) DEFAULT NULL COMMENT 'Позиция.  Может называться по другому, но тогда в cdbfrselectmodel надо указать, как именно',
  `name` varchar(64) DEFAULT NULL COMMENT 'Имя пользователя',
  `surname` varchar(64) DEFAULT NULL COMMENT 'Фамилия пользователя',
  `role` int(11) DEFAULT '0' COMMENT 'Роль пользователя 0 - пользователь 1 - модератор - 2 - админ',
  `current_task` varchar(7) DEFAULT NULL COMMENT 'Выбранная в данный момент задача формат: Вариант:Задание',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=47 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `pwd`, `email`, `guest_id`, `last_access_time`, `is_deleted`, `date_create`, `delta`, `name`, `surname`, `role`, `current_task`) VALUES
(1, 'e10adc3949ba59abbe56e057f20f883e', 'aso@mail.ru', '524efd274ddd4a42261d6190c5a2efda', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(2, NULL, NULL, '49a984d5595c47177c6834560dcf6fb7', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(3, NULL, NULL, '6340b26f4290f14c2de5f8f284aad08a', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(4, NULL, NULL, '88cb664d4e3825608afc01673232097e', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(5, NULL, NULL, 'c8edff2a2a7e833fd0343d6dc3e09800', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(6, NULL, NULL, 'f4e83885918a4f13f7d02057fda5ccc9', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(7, NULL, NULL, '6b204aa78972395d02206e4d202a93fb', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(8, '07b68be905ddc7243d684007163d9fcd', 'asd@xxc.co', '15728f680e82123d0b0a6a81a126e0b0', NULL, 0, NULL, NULL, 'Lamzin', 'Andrey', 0, NULL),
(9, NULL, NULL, '10607d9e2861ddebe64e7c6053e781ac', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(10, '07b68be905ddc7243d684007163d9fcd', 'aso@qwe.ru', '7cb5d5c9f4fb490526a10590ee09f9a8', NULL, 0, NULL, NULL, 'Andrey', 'Lamzin', 2, '2:2'),
(11, NULL, NULL, '2077a0d04ff80532ccf5662eebb23faf', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(12, NULL, NULL, 'cc2e680a499bdf47bfc26f9c3a6684c7', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(13, '07b68be905ddc7243d684007163d9fcd', 'ato@toe.ru', 'e6ba67bbbea643d0a750943239e9cf8c', NULL, 0, NULL, NULL, 'Второй', 'Юзверь', 0, NULL),
(14, NULL, NULL, '7f0fbae4da2245bdad8c360d80773715', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(15, '07b68be905ddc7243d684007163d9fcd', 'tester@qwe.ru', 'ee81ee465008ba22559b1cc5acd5fed0', NULL, 0, NULL, NULL, 'tester', 'testEr', 0, NULL),
(16, NULL, NULL, 'a684cf60f26c85380733cee9f3cb1d04', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(17, NULL, NULL, '2b989d05a400afd13fa3fe27e7ac30d6', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(18, NULL, NULL, '336f0b6a2e6e9f12c92e5a9dd2056439', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(19, NULL, NULL, '72d11371efba801d70e97cf4e2dcc4bf', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(20, NULL, NULL, '14cc3ad4ce3583cb9aee49489bdb3ee8', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(21, NULL, NULL, 'fdff36296a59cc5ece838c1071efca5d', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(22, NULL, NULL, '8584b582dc2ec4296a88e2a53bdd2f35', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(23, '07b68be905ddc7243d684007163d9fcd', 'inn@qw.qw', '3624ae185da890ae209f5e7dab336620', NULL, 0, NULL, NULL, 'innovator', 'jo', 0, NULL),
(24, NULL, NULL, 'a3ff4c0b7d1c801580b7adad297838b4', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(25, NULL, NULL, 'e01bd7e82e81dc052653daeaf9a85f96', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(26, NULL, NULL, '8b24dfc5568bdc833948700d3f89868b', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(27, NULL, NULL, 'd19f7e448a86fc02ef1eae3af3f5bcb2', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(28, NULL, NULL, '57df5695283c047d5355d9f08be422e0', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(29, '07b68be905ddc7243d684007163d9fcd', 'test@test.test', '411ded4239db6336b7f2a411c8827d87', NULL, 0, NULL, NULL, 'Tester', 'Bekon', 0, '1:1'),
(30, NULL, NULL, '88790d5493e968c77f1c137dc4d008ed', NULL, 0, NULL, NULL, NULL, NULL, 0, '1:1'),
(31, NULL, NULL, 'a0e45c180b7014028a8c7a5ad3e7b563', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(32, NULL, NULL, '35f0758948cb69bfd3ad55cf3ecd2572', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(33, NULL, NULL, '25fec4079092b3f661d2a360e761066b', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(34, '07b68be905ddc7243d684007163d9fcd', 'yami@qw.qw', 'b7ea2605b0e7a8a27eda188f220f2ee9', NULL, 0, NULL, NULL, 'yam', 'Yaami', 0, NULL),
(35, NULL, NULL, '53cbded8ea2925ab46c66363f4addca8', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(36, NULL, NULL, 'fe9258dce1328438eee3344af5749fef', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(37, NULL, NULL, '765d69b23b7f665d09b69898e0c50df2', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(38, NULL, NULL, '46e0af6e61689ac8ee05e8d2e4811651', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(39, NULL, NULL, 'b1e945e97ce17b857783de4592607a98', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(40, NULL, NULL, '021e0d14843ff0e1a60eb75b2b39383b', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(41, NULL, NULL, 'cfffb6110f174a6a952de2e16da4482a', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(42, NULL, NULL, 'f69ab22fd1c11891116f80261c8b726c', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(43, NULL, NULL, 'fd3b78a1626179fbe07cef518833ddb7', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(44, NULL, NULL, '18a9d9fea117b08cbb294d6f890c7439', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(45, NULL, NULL, '4659ea8bee80a6549abf2e0da3d7c83d', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL),
(46, NULL, NULL, '7485186624af3119cc70f46c14fe6389', NULL, 0, NULL, NULL, NULL, NULL, 0, '1:1');

-- --------------------------------------------------------

--
-- Структура таблицы `user_complete_tasks`
--

CREATE TABLE IF NOT EXISTS `user_complete_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Первичный ключ.',
  `uid` int(11) DEFAULT NULL COMMENT 'Пользователь',
  `var` int(11) DEFAULT NULL COMMENT 'Вариант',
  `task` int(11) DEFAULT NULL COMMENT 'Номер задания',
  `files` varchar(128) DEFAULT NULL COMMENT 'Файлы пользователя содержащие решения формат: номера через запятую',
  `rating` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_task` (`uid`,`var`,`task`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `user_complete_tasks`
--

INSERT INTO `user_complete_tasks` (`id`, `uid`, `var`, `task`, `files`, `rating`) VALUES
(1, 10, 1, 2, '38,34', 1),
(2, 29, 1, 2, '40,39', 2),
(3, 34, 1, 2, '42', 1),
(4, 10, 2, 2, '16,15', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `user_votes`
--

CREATE TABLE IF NOT EXISTS `user_votes` (
  `uid` int(11) DEFAULT NULL COMMENT 'Голосовавший Пользователь',
  `decision_id` int(11) DEFAULT NULL COMMENT 'Номер решения см. таблицу user_complete_tasks',
  `sign` tinyint(4) DEFAULT NULL COMMENT 'Тип голоса',
  UNIQUE KEY `uniq_vote` (`uid`,`decision_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user_votes`
--

INSERT INTO `user_votes` (`uid`, `decision_id`, `sign`) VALUES
(10, 2, 1),
(34, 2, 1),
(34, 1, 1),
(10, 3, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
